ALTER TABLE hostname ADD COLUMN boolean track;
